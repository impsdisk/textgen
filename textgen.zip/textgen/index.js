

const fs = require('fs')
const { createCanvas, loadImage } = require('canvas')
var randomHaiku = require('./node_modules/haiku-generator-master/haiku')
var randomfirst = require('./node_modules/haiku-generator-master/haiku')
var createrandomfirst = require('./node_modules/haiku-generator-master/haiku')
var createrandomsecond = require('./node_modules/haiku-generator-master/haiku')
var createrandomthird = require('./node_modules/haiku-generator-master/haiku')

const width = 1200
const height = 630

const canvas = createCanvas(width, height)
const context = canvas.getContext('2d')

context.fillStyle = '#000'
context.fillRect(0, 0, width, height)

context.font = 'bold 35pt impact'
context.textAlign = 'center'
context.textBaseline = 'top'
context.fillStyle = '#3574d4'

const textWidth = context.measureText(`${randomfirst}`).width
context.fillRect(600 - textWidth / 2 - 10, 170 - 5, textWidth + 20, 120)
context.fillStyle = '#fff'
context.fillText(`${randomHaiku}`, 600, 170)

context.fillStyle = '#fff'
context.font = 'bold 30pt Arial'
context.fillText('hello', 600, 530)

loadImage('./logo.png').then(image => {
  context.drawImage(image, 340, 515, 70, 70)
  const buffer = canvas.toBuffer('image/png')
  fs.writeFileSync('./test.png', buffer)
})
